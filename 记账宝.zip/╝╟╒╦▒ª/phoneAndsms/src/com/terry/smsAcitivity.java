package com.terry;

import java.util.List;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.gsm.SmsManager; 
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

@SuppressWarnings("deprecation")
public class smsAcitivity extends Activity {
	private Button myButton;
	private EditText myEditText;
	private EditText EditText2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sms);
		
		myButton=(Button)findViewById(R.id.button);
		myEditText=(EditText)findViewById(R.id.mobile);
		EditText2=(EditText)findViewById(R.id.content);
		
		myButton.setOnClickListener(new OnClickListener() {
			 
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				 String mobile=myEditText.getText().toString();
				 String content=EditText2.getText().toString();
				SmsManager sms=SmsManager.getDefault();
				PendingIntent sentintent =PendingIntent.getBroadcast(smsAcitivity.this,
						0, new Intent(), 0);
				try {
					if(content.length()>70)
					{
						List<String> msgs=sms.divideMessage(content);
						for(String msg:msgs)
						{
							sms.sendTextMessage(mobile, null, msg, sentintent, null); 
						}
					}
					else
					{
					
						sms.sendTextMessage(mobile, null, content, sentintent, null);
					}
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
				Toast.makeText(smsAcitivity.this, "���ŷ��ͳɹ�", 1000).show();
			}
		});
		
	}
}
