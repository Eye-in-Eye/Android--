package com.terry;
 

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.*;
public class phoneAndsmsAcitivity extends Activity {
	private Button myButton;
	private EditText myEditText;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        myButton=(Button)findViewById(R.id.button);
        myEditText=(EditText)findViewById(R.id.mobile);
        
        myButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(myEditText.getText().length()>0)
				{
					Intent myIntent=new Intent(Intent.ACTION_CALL,Uri.parse
							("tel:"+myEditText.getText().toString()));
				phoneAndsmsAcitivity.this.startActivity(myIntent);
				}
			}
		});
    }
}